export type Guru = {
  id: number,
  name: string,
  jabatan: string,
  description: string,
  gender: string,
  birthday: string,
  address: string,
  phone: string,
  email: string,
  image: string,
  status: string,
}