export type Gender = [
  'Laki-laki',
  'Perempuan'
];