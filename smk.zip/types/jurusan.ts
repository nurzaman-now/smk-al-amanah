

export type Jurusan = {
  id: number,
  title: string,
  paragraph: string,
  list?: string[],
  image: string,
}