export type Agenda = {
  id: number;
  name: string;
  date: string;
  description: string;
};
